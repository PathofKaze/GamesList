package vttp2022.ssf.assessment.videosearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideosearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideosearchApplication.class, args);
	}

}
