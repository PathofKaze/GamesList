package vttp2022.ssf.assessment.videosearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideosearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
